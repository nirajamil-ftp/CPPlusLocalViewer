# CP Plus Local Viewer

Android Expo app based on CPPlusLocalViewer.

## Build

1. Install dependencies with `npm install`.
2. Set the local camera/server stream URL in `.env` as `STREAM_URL`.
3. Run `npx expo prebuild --platform android`.
4. Run `cd android && ./gradlew assembleDebug`.

The app icon is `assets/icon.png`.
